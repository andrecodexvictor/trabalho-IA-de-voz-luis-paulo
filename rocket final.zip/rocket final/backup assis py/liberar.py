def atuar_sobre_liberar(foguete, estagio):
    if estagio == 1:
        if not foguete.is_launched:
            return "Erro: Foguete ainda não decolou."
        if foguete.current_stage >= 1:
            return "Erro: Estágio 1 já foi liberado."
        foguete.current_stage = 1
        return "Liberando estágio 1. Estágio 1 liberado com sucesso."
    
    elif estagio == 2:
        if foguete.current_stage != 1:
            return "Erro: Primeiro estágio não liberado."
        if foguete.current_stage >= 2:
            return "Erro: Estágio 2 já foi liberado."
        foguete.current_stage = 2
        return "Liberando estágio 2. Estágio 2 liberado com sucesso."
    
    return "Erro: Estágio inválido."
def atuar_sobre_satelite(foguete):
    if foguete.is_launched and foguete.current_stage >= 2 and not foguete.satellite_deployed:
        foguete.satellite_deployed = True
        return "Satélite liberado e pronto para uso."
    return "Não é possível liberar satélite - condições não atendidas."

def liberar_estagio(numero):
    print(f"Executando função: liberar_estagio({numero})")
    print(f"Mecanismos de separação do estágio {numero} ativados")

def liberar_satelite():
    print("Executando função: liberar_satelite()")
    print("Mecanismo de liberação do satélite ativado")


