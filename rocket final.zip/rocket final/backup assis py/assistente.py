from inicializador_modelos import *
from transcritor import *
import numpy as np
from nltk import word_tokenize, corpus
from nltk.corpus import stopwords
import torch
from decolagem import atuar_sobre_decolagem
from liberar import atuar_sobre_liberar
from pouso import atuar_sobre_pouso
from satelite import atuar_sobre_satelite
from decolagem import iniciar_decolagem
from liberar import liberar_estagio, liberar_satelite
from pouso import pousar_booster
import secrets
import pyaudio
import wave
import time
import json

import os

AMOSTRAS = 1024
TAXA_AMOSTRAGEM = 16_000
FORMATO = pyaudio.paInt16
CANAIS = 1
TEMPO_DE_GRAVACAO = 5
IDIOMA_CORPUS = "portuguese"
CAMINHO_AUDIO_FALA = "C:\\Users\\adm\Downloads\\rocket (1)\\temp"
CONFIGURACAO = "C:\\Users\\adm\Downloads\\rocket (1)\\config.json"
TEMPO_MAXIMO = 60  # Limite máximo de captura (segundos)
INTERVALO_MEDICAO_CHAMADO = 0.1  # Intervalo de medição de chamado (segundos)
SILENCIO_LIMIAR = 2000  # Aumentar de 500 para 2000
TEMPO_ESPERA_SILENCIO = 0.5  # Reduzir de 1.0 para 0.5 segundo

def load_config():
    with open('config.json', 'r', encoding='utf-8') as f:
        return json.load(f)
def iniciar(dispositivo):
    gravador = pyaudio.PyAudio()

    assistente_iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)
    palavras_de_parada, acoes = None, None
    
    if assistente_iniciado:
        palavras_de_parada = corpus.stopwords.words(IDIOMA_CORPUS)
        
        with open(CONFIGURACAO, "r") as arquivo_configuracao:
            configuracao = json.load(arquivo_configuracao)
            acoes = configuracao["acoes"]
    
    atuadores_iniciados, atuadores = iniciar_atuadores()
    
    return assistente_iniciado, processador, modelo, gravador, palavras_de_parada, acoes, atuadores_iniciados, atuadores


def handle_command(transcribed_text):
    config = load_config()
    
    for acao in config['acoes']:
        if any(padrao.lower() in transcribed_text.lower() for padrao in acao['padroes']):
            
            if acao['identificador'] == 'decolagem':
                iniciar_decolagem()
                return acao['resposta']
                
            elif acao['identificador'] in ['estagio1', 'estagio2']:
                estagio = 1 if acao['identificador'] == 'estagio1' else 2
                liberar_estagio(estagio)
                return acao['resposta']
                
            elif acao['identificador'] == 'pouso':
                pousar_booster()
                return acao['resposta']
                
            elif acao['identificador'] == 'satelite':
                liberar_satelite()
                return acao['resposta']
    
    return "Comando não reconhecido"


def executar_acao(acao, objeto_comando, decolagem, liberar, pousar):
    if acao["acao"] == "decolagem":
        return decolagem(objeto_comando)
    elif acao["acao"] == "liberar":
        return liberar(objeto_comando)
    elif acao["acao"] == "pouso":
        return pousar(objeto_comando)
    elif acao["acao"] == "satelite":
        return satelite(objeto_comando)
    else:
        return "Ação não reconhecida."


class Foguete:
        def __init__(self):
            self.is_launched = False
            self.current_stage = 0
            self.satellite_deployed = False

def decolagem_atuador(foguete):
    if not foguete.is_launched:
        foguete.is_launched = True
        return "Iniciando decolagem. Preparando contagem regressiva."
    return "Foguete já decolou."

def liberar_atuador(foguete, estagio):
    if foguete.is_launched:
        if estagio > foguete.current_stage:
            foguete.current_stage = estagio
            return f"Liberando estágio {estagio}. Estágio {estagio} liberado com sucesso."
        return f"Estágio {estagio} já foi liberado."
    return "Foguete precisa decolar primeiro."

def pousar_atuador(foguete):
    if foguete.is_launched and foguete.current_stage >= 1:
        return "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso."
    return "Não é possível pousar - foguete não decolou ou primeiro estágio não liberado."

def liberar_satelite_atuador(foguete):
    if foguete.is_launched and foguete.current_stage >= 2 and not foguete.satellite_deployed:
        foguete.satellite_deployed = True
        return "Satélite liberado e pronto para uso."
    return "Não é possível liberar satélite - condições não atendidas."

def iniciar_atuadores():
    atuadores = []
    foguete = Foguete()  # Cria uma instância de Foguete

    if iniciar_decolagem(foguete):
        atuador = {}
        atuador["nome"] = "foguete"
        atuador["atuacao"] = lambda: atuar_sobre_decolagem(foguete)
        atuadores.append(atuador)

    if iniciar_liberar(foguete):
        atuador = {}
        atuador["nome"] = "liberar"
        atuador["atuacao"] = lambda estagio: atuar_sobre_liberar(foguete, estagio)
        atuadores.append(atuador)

    if iniciar_pouso(foguete):
        atuador = {}
        atuador["nome"] = "pouso"
        atuador["atuacao"] = lambda: atuar_sobre_pouso(foguete)
        atuadores.append(atuador)

    if iniciar_satelite(foguete):
        atuador = {}
        atuador["nome"] = "satelite"
        atuador["atuacao"] = lambda: atuar_sobre_satelite(foguete)
        atuadores.append(atuador)

    return len(atuadores) > 0, atuadores

# Add these new functions at the top of the file, before iniciar_atuadores()
def iniciar_decolagem(foguete):
    try:
        atuar_sobre_decolagem(foguete)
        return True
    except:
        return False

def iniciar_liberar(foguete):
    try:
        atuar_sobre_liberar(foguete, 1)  # Test with stage 1
        return True
    except:
        return False

def iniciar_pouso(foguete):
    try:
        atuar_sobre_pouso(foguete)
        return True
    except:
        return False

def iniciar_satelite(foguete):
    try:
        atuar_sobre_satelite(foguete)
        return True
    except:
        return False
def executar_acao(acao, objeto_comando, foguete):
    tipo_acao = acao["tipo"]
    
    if tipo_acao == "decolagem":
        return atuar_sobre_decolagem(foguete)
    elif tipo_acao == "liberar":
        return atuar_sobre_liberar(foguete, objeto_comando)
    elif tipo_acao == "pouso":
        return atuar_sobre_pouso(foguete)
    elif tipo_acao == "satelite":
        return atuar_sobre_satelite(foguete)
    else:
        return "Ação não reconhecida"

def capturar_audio_microfone(gravador):
    fluxo = gravador.open(format=FORMATO,
                         channels=CANAIS,
                         rate=TAXA_AMOSTRAGEM,
                         input=True,
                         frames_per_buffer=AMOSTRAS)

    print("* Gravação iniciada - fale seu comando *", flush=True)
    frames = []
    ultimo_audio = time.time()
    gravando = False
    
    try:
        while True:
            audio_dados = fluxo.read(AMOSTRAS, exception_on_overflow=False)
            array_audio = np.frombuffer(audio_dados, dtype=np.int16)
            
            # Fix: Ensure we're calculating with absolute values and handling potential zeros
            squared_values = array_audio.astype(np.float64)**2
            mean_squared = np.mean(squared_values)
            volume_rms = np.sqrt(max(0, mean_squared))  # Prevent negative values
            
            if volume_rms > SILENCIO_LIMIAR:
                print("Som detectado - Volume:", volume_rms)
                gravando = True
                ultimo_audio = time.time()
                frames.append(audio_dados)
            
            elif gravando:
                frames.append(audio_dados)
                if (time.time() - ultimo_audio) > TEMPO_ESPERA_SILENCIO:
                    print("Comando finalizado - Processando...")
                    return b''.join(frames)
                
    except Exception as e:
        print(f"Erro na captura: {e}")
        return None
    finally:
        fluxo.stop_stream()
        fluxo.close()


def capturar_e_transcrever(dispositivo, modelo, processador):
    gravador = pyaudio.PyAudio()
    audio = capturar_audio_microfone(gravador)
    gravado, arquivo = gravar_fala_arquivo(audio, "comando")
    
    if gravado:
        fala = carregar_fala(arquivo)
        transcricao = transcrever_fala(dispositivo, fala, modelo, processador)
        
        if transcricao:
            return transcricao
        else:
            print("Transcrição vazia")
            return None
    else:
        print("Erro ao gravar arquivo")
        return None 

def capturar_e_transcrever(dispositivo, modelo, processador):
    gravador = pyaudio.PyAudio()
    audio = capturar_audio_microfone(gravador)
    gravado, arquivo = gravar_fala_arquivo(audio, "comando")
    
    if gravado:
        fala = carregar_fala(arquivo)
        transcricao = transcrever_fala(dispositivo, fala, modelo, processador)
        
        if transcricao:
            return transcricao
        else:
            print("Transcrição vazia")
            return None
    else:
        print("Erro ao gravar arquivo")
        return None

def processar_com_torchaudio(audio_bytes, dispositivo):
    try:
        print("Processando áudio...")
        
        # Convert bytes to numpy array
        audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32)
        print(f"Shape do array numpy: {audio_np.shape}")
        
        # Normalize
        audio_np = audio_np / 32768.0
        
        # Convert to tensor and ensure correct shape
        audio_tensor = torch.FloatTensor(audio_np)
        # Remove any extra dimensions and keep only [sequence_length]
        audio_tensor = audio_tensor.squeeze()
        print(f"Shape do tensor final: {audio_tensor.shape}")
        
        return audio_tensor
        
    except Exception as e:
        print(f"Erro no processamento do áudio: {e}")
        return None



def capturar_e_transcrever(dispositivo, modelo, processador):
    gravador = pyaudio.PyAudio()
    stream = gravador.open(
        format=FORMATO,
        channels=CANAIS,
        rate=TAXA_AMOSTRAGEM,
        input=True,
        frames_per_buffer=AMOSTRAS,
    )

    print("Esperando comando 'rocket'...")
    buffer_audio = []
    buffer_audio_silencio = []
    buffer_audio_chamado = []

    try:
        inicio_silencio = None
        dentro_chamado = False
        ultima_leitura_chamado = 0
        
        while True:
            dados = stream.read(AMOSTRAS, exception_on_overflow=False)
            dados_np = np.frombuffer(dados, dtype=np.int16)

            # Detecta se há som
            volume = np.abs(dados_np).mean()
            if volume > SILENCIO_LIMIAR:
                print(".", end="", flush=True)  # Indicador visual de som detectado
                
                buffer_audio_chamado.append(dados)
                if len(buffer_audio_chamado) > 20:
                    buffer_audio_chamado.pop(0)

                if not dentro_chamado:
                    if time.time() - ultima_leitura_chamado > INTERVALO_MEDICAO_CHAMADO:
                        ultima_leitura_chamado = time.time()
                        if buffer_audio_chamado:
                            audio_bytes = b"".join(buffer_audio_chamado)
                            tensor_audio = processar_com_torchaudio(audio_bytes, TAXA_AMOSTRAGEM)
                            texto_wake_up = transcrever_fala(dispositivo, tensor_audio, modelo, processador)
                            
                    if texto_wake_up:
                                print(f"\nDetectado: {texto_wake_up}")
        # Change "rocket" to "foguete" for Portuguese
                                if "rocket" in texto_wake_up.lower():
                                    print("\nComando 'rocket' detectado! Aguardando instrução...")
                                    dentro_chamado = True
                                    buffer_audio = []

            # Se estiver esperando comando
            if dentro_chamado:
                if volume > SILENCIO_LIMIAR:
                    buffer_audio.append(dados)
                    inicio_silencio = None
                else:
                    if inicio_silencio is None:
                        inicio_silencio = time.time()
                        buffer_audio.append(dados)
                    elif time.time() - inicio_silencio < TEMPO_ESPERA_SILENCIO:
                        buffer_audio.append(dados)
                    else:
                        if buffer_audio:
                            print("\nProcessando comando...")
                            audio_bytes = b"".join(buffer_audio)
                            tensor_audio = processar_com_torchaudio(audio_bytes, TAXA_AMOSTRAGEM)
                            comando = transcrever_fala(dispositivo, tensor_audio, modelo, processador)
                            
                            if comando:
                                print(f"Comando reconhecido: {comando}")
                                return comando
                            
                            dentro_chamado = False
                            buffer_audio = []

    except KeyboardInterrupt:
        print("\nFinalizando...")
    finally:
        stream.stop_stream()
        stream.close()
        gravador.terminate()



def main():
    dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
    print(f"Usando dispositivo: {dispositivo}")
    
    iniciado, processador, modelo, gravador, palavras_parada, acoes, atuadores_iniciados, atuadores = iniciar(dispositivo)

    if iniciado and atuadores_iniciados:
        print("\nAssistente iniciado! Diga 'rocket' para começar.")
        try:
            while True:
                comando = capturar_e_transcrever(dispositivo, modelo, processador)
                if comando:
                    print("\nExecutando comando...")
                    validar_comando(acoes, comando, palavras_parada, atuadores)
                    print("\nAguardando próximo comando 'rocket'...")
                
        except KeyboardInterrupt:
            print("\nAssistente finalizado pelo usuário")
        finally:
            gravador.terminate()
    else:
        print("Falha ao iniciar o assistente ou atuadores")

        print("Falha ao iniciar o assistente ou atuadores")


if __name__ == "__main__":
    main()
