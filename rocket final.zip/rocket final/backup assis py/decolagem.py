def atuar_sobre_decolagem(foguete):
    if not foguete.is_launched:
        foguete.is_launched = True
        return "Iniciando decolagem. Preparando contagem regressiva."
    return "Foguete já decolou."

def iniciar_decolagem():
    print("Executando função: iniciar_decolagem()")
    print("Sistema de propulsão ativado")
    print("Checagem de sistemas completa")

    try:
        atuar_sobre_decolagem(foguete)
        return True
    except:
        return False
