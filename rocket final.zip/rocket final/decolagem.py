def atuar_sobre_decolagem(foguete):
    if not foguete.is_launched:
        foguete.is_launched = True
        return "Iniciando decolagem. Preparando contagem regressiva."
    return "Foguete já decolou."


   