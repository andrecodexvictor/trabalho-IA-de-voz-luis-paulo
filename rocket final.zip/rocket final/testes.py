import unittest
from assistente import *

DECOLAGEM = "C:\\Users\\adm\Downloads\\rocket (1)\\audios\\decolagem.wav"
ESTAGIO1 = "C:\\Users\\adm\\Downloads\\rocket (1)\\audios\\estagio1.wav"
ESTAGIO2 = "C:\\Users\\adm\Downloads\\rocket (1)\\audios\\estagio2.wav"
POUSO = "C:\\Users\\adm\Downloads\rocket (1)\audios\pouso.wav"
SATELITE = "C:\\Users\\adm\Downloads\\rocket (1)\\audios\\satelite.wav"


class Teste(unittest.TestCase):
    def setUp(self):
        self.dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
        iniciado, self.processador, self.modelo, self.gravador, self.palavras_de_parada, self.acoes = iniciar(self.dispositivo)

        self.assertTrue(iniciado)

        return super().setUp()

    def test_decolagem(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(DECOLAGEM), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")

    def test_estagio1(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(ESTAGIO1), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")

    def test_estagio2(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(ESTAGIO2), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")

    def test_satelite(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(SATELITE), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")
    def test_pouso(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(POUSO), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")


if __name__ == "__main__":
    unittest.main() 