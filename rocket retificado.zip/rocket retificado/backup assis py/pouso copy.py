# pouso.py
def atuar_sobre_pouso(foguete):
    if foguete.is_launched and foguete.current_stage >= 1:
        return "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso."
    return "Não é possível pousar - foguete não decolou ou primeiro estágio não liberado."

def pousar_booster():
    print("Executando função: pousar_booster()")
    print("Sistema de pouso automático ativado")
    print("Controle de propulsores para pouso iniciado")

