from inicializador_modelos import *
from transcritor import *
import numpy as np
from nltk import word_tokenize, corpus
from nltk.corpus import stopwords

import secrets
import pyaudio
import wave
import time
import json

import os

AMOSTRAS = 1024
TAXA_AMOSTRAGEM = 16_000
FORMATO = pyaudio.paInt16
CANAIS = 1
TEMPO_DE_GRAVACAO = 5
IDIOMA_CORPUS = "portuguese"
CAMINHO_AUDIO_FALA = "temp"
CONFIGURACAO = "C:\\Users\\adm\Downloads\\rocket (1)\\config.json"
SILENCIO_LIMIAR = 500  # Limiar para considerar como silêncio
TEMPO_MAXIMO = 60  # Limite máximo de captura (segundos)
TEMPO_ESPERA_SILENCIO = 1.0  # Tempo de espera em segundos antes de transcrever
INTERVALO_MEDICAO_CHAMADO = 0.1  # Intervalo de medição de chamado (segundos)

def iniciar(dispositivo):
    gravador = pyaudio.PyAudio()

    assistente_iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)
    palavras_de_parada, acoes = None , None
    if assistente_iniciado:
        palavras_de_parada = corpus.stopwords.words(IDIOMA_CORPUS)
        
        with open(CONFIGURACAO, "r") as arquivo_configuracao:
            configuracao = json.load(arquivo_configuracao)
            acoes = configuracao["acoes"]

    return assistente_iniciado, processador, modelo, gravador, palavras_de_parada, acoes

def iniciar(dispositivo):
    gravador = pyaudio.PyAudio()
    assistente_iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)
    palavras_de_parada, acoes = None, None
    if assistente_iniciado:
        palavras_de_parada = stopwords.words("portuguese")  # Corrigido aqui
        with open(CONFIGURACAO, "r") as arquivo_configuracao:
            configuracao = json.load(arquivo_configuracao)
            acoes = configuracao["acoes"]
    return assistente_iniciado, processador, modelo, gravador, palavras_de_parada, acoes




def validar_comando(acoes, comando, palavras_de_parada, lista):
    texto = remover_comando_wake_up(comando)
    comando_separado = separar_comando_e_remover_palavras_parada(texto, palavras_de_parada)

    for acao in acoes:
        if acao["comando"] == comando_separado[0]:
            executar_acao(acao, get_objeto_comando(texto), lista)


class Foguete:
    def __init__(self):
        self.is_launched = False
        self.current_stage = 0
        self.satellite_deployed = False

def iniciar_atuadores():
    atuadores = []

    if iniciar_decolagem():
        atuador = {}
        atuador["nome"] = "foguete"
        atuador["atuacao"] = atuar_sobre_decolagem

        atuadores.append(atuador)

    if iniciar_liberar():
        atuador = {}
        atuador["nome"] = "liberar"
        atuador["atuacao"] = atuar_sobre_liberar

        atuadores.append(atuador)
    if iniciar_pouso():
        atuador = {}
        atuador["nome"] = "pouso"
        atuador["atuacao"] = atuar_sobre_pouso

        atuadores.append(atuador)

    if iniciar_satelite():
        atuador = {}
        atuador["nome"] = "satelite"
        atuador["atuacao"] = atuar_sobre_satelite

        atuadores.append(atuador)

    return len(atuadores) > 0, atuadores
def executar_acao(foguete, acao):
    if acao["identificador"] == "decolagem":
        return decolagem_atuador(foguete)
    elif acao["identificador"] == "estagio1":
        return liberar_atuador(foguete, 1)
    elif acao["identificador"] == "estagio2":
        return liberar_atuador(foguete, 2)
    elif acao["identificador"] == "pouso":
        return pousar_atuador(foguete)
    elif acao["identificador"] == "satelite":
        return liberar_satelite_atuador(foguete)
    return "Ação não reconhecida."


# Função para capturar áudio do microfone
def capturar_audio_microfone(gravador):
    # Configurando o fluxo de áudio
    fluxo = gravador.open(format=FORMATO,
                          channels=CANAIS,
                          rate=TAXA_AMOSTRAGEM,
                          input=True,
                          frames_per_buffer=AMOSTRAS)

    print("* Gravação iniciada - fale seu comando *")
    frames = []
    
    # Adicionando detecção de silêncio
    ultimo_audio = time.time()
    gravando = False
    
    try:
        while True:
            audio_dados = fluxo.read(AMOSTRAS, exception_on_overflow=False)
            array_audio = np.frombuffer(audio_dados, dtype=np.int16)
            
            # Detecta se há som (volume acima do limiar)
            volume_rms = np.sqrt(np.mean(array_audio**2))
            
            if volume_rms > SILENCIO_LIMIAR:
                gravando = True
                ultimo_audio = time.time()
                frames.append(audio_dados)
            
            # Se estiver gravando e houver silêncio por TEMPO_ESPERA_SILENCIO segundos
            elif gravando and (time.time() - ultimo_audio) > TEMPO_ESPERA_SILENCIO:
                return b''.join(frames)
                
            # Limite de tempo máximo
            if len(frames) > TEMPO_MAXIMO * (TAXA_AMOSTRAGEM / AMOSTRAS):
                return b''.join(frames)
                
    except Exception as e:
        print(f"Erro na captura: {e}")
        return None
    finally:
        fluxo.stop_stream()
        fluxo.close()


# Função para processar dados de áudio com o transcritor
def processador_audio_para_comando(audio_dados, dispositivo, modelo, processador):
    try:
        # Convertendo dados brutos para waveform com função externa do transcritor
        fala = np.frombuffer(audio_dados, dtype=np.int16).astype(np.float32) / 32768.0  # Normalizando
        transcricao = transcrever_fala(dispositivo, fala, modelo, processador)  # Chamando transcritor externo
        if transcricao:
            print(f"Texto transcrito: {transcricao}")
            return transcricao
    except Exception as e:
        print(f"Erro ao processar áudio: {e}")
        return None


def main():
    dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
    foguete = Foguete()
    iniciado, processador, modelo, gravador, palavras_parada, acoes = iniciar(dispositivo)

    if iniciado:
        try:
            while True:
                # Captura áudio até detectar silêncio
                audio_dados = capturar_audio_microfone(gravador)
                if audio_dados:
                    print("Processando comando...")
                    comando = processador_audio_para_comando(audio_dados, dispositivo, modelo, processador)

                    if comando:
                        print(f"Comando detectado: {comando}")
                        for acao in acoes:
                            if isinstance(acao["comando"], str) and acao["comando"].lower() in comando.lower():
                                resposta = executar_acao(foguete, acao, comando)
                                print(f"Resposta: {resposta}")
                                break
                
                time.sleep(0.1)  # Pequena pausa para não sobrecarregar o CPU
                
        except KeyboardInterrupt:
            print("\nAssistente finalizado pelo usuário")
        finally:
            gravador.terminate()

if __name__ == "__main__":
    main()
