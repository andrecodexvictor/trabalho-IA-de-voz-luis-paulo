import json
import speech_recognition as sr
import nltk
from nltk.tokenize import word_tokenize
from transformers import pipeline
import numpy as np
import time
from pathlib import Path
import torch
import threading
import queue

class RocketAssistant:
    def __init__(self, config_path="config.json"):
        # Load configuration
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # Initialize NLTK
        nltk.download('punkt')
        
        # Initialize speech recognition
        self.recognizer = sr.Recognizer()
        
        # Initialize the speech recognition pipeline
        self.asr_pipeline = pipeline(
            task=self.config['model']['pipeline'],
            model=self.config['model']['name']
        )
        
        # Initialize audio queue
        self.audio_queue = queue.Queue()

    def process_audio(self, indata, frames, time, status):
        """Callback for audio processing"""
        if status:
            print(status)
        self.audio_queue.put(indata.copy())

    def listen(self):
        """Listen for voice input"""
        try:
            with sr.Microphone() as source:
                print("Listening...")
                audio = self.recognizer.listen(source)
                return audio
        except Exception as e:
            print(f"Error listening: {e}")
            return None

    def recognize_speech(self, audio):
        """Convert speech to text"""
        try:
            text = self.recognizer.recognize_google(audio, language=self.config['language'])
            return text.lower()
        except Exception as e:
            print(f"Error recognizing speech: {e}")
            return None

    def process_command(self, text):
        """Process the recognized command"""
        if not text:
            return None
            
        tokens = word_tokenize(text)
        
        for command, details in self.config['commands'].items():
            for pattern in details['patterns']:
                if all(word in text for word in pattern.split()):
                    response = details['response']
                    if 'countdown' in details and details['countdown']:
                        self.perform_countdown()
                    return response
        
        return "Comando não reconhecido. Por favor, tente novamente."

    def perform_countdown(self):
        """Perform launch countdown"""
        for i in range(10, -1, -1):
            if i == 0:
                print("Decolagem!")
                time.sleep(1)
            else:
                print(f"{i}...")
                time.sleep(1)

    def run(self):
        """Main loop for the assistant"""
        print(f"{self.config['assistant_name']} assistente iniciado. Aguardando comandos...")
        
        while True:
            audio = self.listen()
            if audio:
                text = self.recognize_speech(audio)
                if text:
                    print(f"Comando reconhecido: {text}")
                    response = self.process_command(text)
                    print(f"Resposta: {response}")

    def process_recorded_audio(self, audio_file):
        """Process pre-recorded audio file for testing"""
        try:
            with sr.AudioFile(audio_file) as source:
                audio = self.recognizer.record(source)
                text = self.recognize_speech(audio)
                return self.process_command(text)
        except Exception as e:
            print(f"Error processing recorded audio: {e}")
            return None

if __name__ == "__main__":
    assistant = RocketAssistant()
    assistant.run()