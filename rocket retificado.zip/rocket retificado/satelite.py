# satelite.py
def atuar_sobre_satelite(foguete):
    if foguete.is_launched and foguete.current_stage >= 2 and not foguete.satellite_deployed:
        foguete.satellite_deployed = True
        return "Satélite liberado e pronto para uso."
    return "Não é possível liberar satélite - condições não atendidas."
